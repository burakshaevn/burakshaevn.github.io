# LoaderDawn
Бот для скачивания музыки из ВК

Установка:
```sh
pip3 install -r requirements.txt
mkdir logs
nano settings.txt
```

Пример файла settings.txt:
```
#В файле settings.txt строчки, начинающиеся с решётки, а также пустые строчки, игнорируются

#api_v
5.84

#Логин вспомогательной страницы 
my.email@mail.com

#Логин вспомогательной страницы
my_Password

#ID вспомогательной страницы
12345678

#Токен группы
fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff

#ID группы
-11111111

#Токены яндекс.диска - можно писать сколько угодно - читаются до конца файла
AQAAAAAffffffffffffffffffffffffffffffff
AQAAAAAfffffffffffffffffffffffffffffffe
```
