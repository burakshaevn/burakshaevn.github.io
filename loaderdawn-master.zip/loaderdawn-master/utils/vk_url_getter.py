import vk_api

def get_vk_url(audios):
    f